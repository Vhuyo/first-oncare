﻿/* Daniel Wium
 CSIS1614 Chapter 1
 06 Februrary 2020 */

using System; // using directives allow us to utilise the namespaces in the .NET Framework. 

namespace HelloWorld
{
    class Program
    {
        static void Main()
        {
            // Print the text "Hello, World!" to the console window.
            Console.Write("Hello, World!"); // The Write() method is located in the Console class, which in turn is located in the System namespace, which is available due to the using directive in line 5.
            // Wait for the user to press any key before the application exits.
            Console.ReadKey();
        }
    }
}
